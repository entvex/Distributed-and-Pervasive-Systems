#! /bin/bash
mpiexec -n 4 python mpi_bully.py
