#! /bin/bash

./socket_bully.py 1 4 &
./socket_bully.py 2 4 &
./socket_bully.py 3 4 &
./socket_bully.py 4 4 &
